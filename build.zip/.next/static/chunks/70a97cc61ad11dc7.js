__turbopack_load_page_chunks__("/_error", [
  "static/chunks/627583eb29d36a3d.js",
  "static/chunks/ab7b0865f20e05d2.js",
  "static/chunks/turbopack-ea14393e7dd1cc28.js"
])
