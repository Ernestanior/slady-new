__turbopack_load_page_chunks__("/_app", [
  "static/chunks/d88c63447464f752.js",
  "static/chunks/14922e54c93ca415.js",
  "static/chunks/turbopack-77a37c3eccbf3485.js"
])
