__turbopack_load_page_chunks__("/_app", [
  "static/chunks/d88c63447464f752.js",
  "static/chunks/ab7b0865f20e05d2.js",
  "static/chunks/turbopack-0a97593070b7c05a.js"
])
