__turbopack_load_page_chunks__("/_error", [
  "static/chunks/627583eb29d36a3d.js",
  "static/chunks/14922e54c93ca415.js",
  "static/chunks/turbopack-ec42608afc5115cc.js"
])
