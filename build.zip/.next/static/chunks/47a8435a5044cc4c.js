__turbopack_load_page_chunks__("/_error", [
  "static/chunks/9240179ff9b8591e.js",
  "static/chunks/9d7d85d2c7f9db0c.js",
  "static/chunks/turbopack-7a1d196db4f002f0.js"
])
