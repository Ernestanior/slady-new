__turbopack_load_page_chunks__("/_error", [
  "static/chunks/9240179ff9b8591e.js",
  "static/chunks/343410523882f532.js",
  "static/chunks/turbopack-31316828c0574e95.js"
])
