__turbopack_load_page_chunks__("/_app", [
  "static/chunks/7fc08f8f38a94f67.js",
  "static/chunks/9d7d85d2c7f9db0c.js",
  "static/chunks/turbopack-db8a898f8d15cec9.js"
])
