__turbopack_load_page_chunks__("/_app", [
  "static/chunks/7fc08f8f38a94f67.js",
  "static/chunks/343410523882f532.js",
  "static/chunks/turbopack-86e0f1c97e291c1b.js"
])
