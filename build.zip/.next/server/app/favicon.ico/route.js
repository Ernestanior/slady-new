var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__b8099c0d._.js")
R.c("server/chunks/[root-of-the-server]__cfd766f2._.js")
R.m(21749)
R.m(79176)
module.exports=R.m(79176).exports
