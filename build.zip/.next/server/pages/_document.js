var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__a61145f4._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0c358df7._.js")
R.m(14395)
module.exports=R.m(14395).exports
