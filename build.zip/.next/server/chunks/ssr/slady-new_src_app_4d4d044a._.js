module.exports=[33141,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},75644,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(33141).default,width:256,height:256}}];

//# sourceMappingURL=slady-new_src_app_4d4d044a._.js.map