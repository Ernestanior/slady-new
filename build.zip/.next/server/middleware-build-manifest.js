globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/7fc08f8f38a94f67.js",
      "static/chunks/9d7d85d2c7f9db0c.js",
      "static/chunks/turbopack-db8a898f8d15cec9.js"
    ],
    "/_error": [
      "static/chunks/9240179ff9b8591e.js",
      "static/chunks/9d7d85d2c7f9db0c.js",
      "static/chunks/turbopack-7a1d196db4f002f0.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2a95cc43fca0fdeb.js",
    "static/chunks/af1b9d3c852fc4b5.js",
    "static/chunks/dbf8849b510af83c.js",
    "static/chunks/eefd457a8840f6be.js",
    "static/chunks/turbopack-ae68addbee410331.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];