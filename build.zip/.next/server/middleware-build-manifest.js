globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/d88c63447464f752.js",
      "static/chunks/ab7b0865f20e05d2.js",
      "static/chunks/turbopack-0a97593070b7c05a.js"
    ],
    "/_error": [
      "static/chunks/627583eb29d36a3d.js",
      "static/chunks/ab7b0865f20e05d2.js",
      "static/chunks/turbopack-ea14393e7dd1cc28.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f003e6e8830fdce0.js",
    "static/chunks/af1b9d3c852fc4b5.js",
    "static/chunks/c1bbfd98585cbb3d.js",
    "static/chunks/2a96c1f71b711fc5.js",
    "static/chunks/turbopack-68c16cd8e8f34cbf.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];