globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/d88c63447464f752.js",
      "static/chunks/14922e54c93ca415.js",
      "static/chunks/turbopack-77a37c3eccbf3485.js"
    ],
    "/_error": [
      "static/chunks/627583eb29d36a3d.js",
      "static/chunks/14922e54c93ca415.js",
      "static/chunks/turbopack-ec42608afc5115cc.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3c7495985bb765ba.js",
    "static/chunks/af1b9d3c852fc4b5.js",
    "static/chunks/c1bbfd98585cbb3d.js",
    "static/chunks/2a96c1f71b711fc5.js",
    "static/chunks/turbopack-efa3cd593dc25111.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];