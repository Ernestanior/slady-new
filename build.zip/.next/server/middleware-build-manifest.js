globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/7fc08f8f38a94f67.js",
      "static/chunks/343410523882f532.js",
      "static/chunks/turbopack-86e0f1c97e291c1b.js"
    ],
    "/_error": [
      "static/chunks/9240179ff9b8591e.js",
      "static/chunks/343410523882f532.js",
      "static/chunks/turbopack-31316828c0574e95.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2a95cc43fca0fdeb.js",
    "static/chunks/af1b9d3c852fc4b5.js",
    "static/chunks/fed23aee7661060a.js",
    "static/chunks/2a96c1f71b711fc5.js",
    "static/chunks/turbopack-81a69ccb497f1095.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];